package com.example.saafsound

import android.Manifest
import android.content.ContentUris
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.media.audiofx.Virtualizer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.text.TextUtils
import android.util.LruCache
import android.util.Size
import android.view.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.concurrent.Executors
import kotlin.math.min

class MainActivity : AppCompatActivity() {

    private class Media(val title: String, val uri: Uri, val ms: Long)

    private var videos = listOf<Media>()
    private var music = listOf<Media>()
    private var queue = listOf<Media>()
    private var qi = -1
    private var player: MediaPlayer? = null
    private var eq: Equalizer? = null
    private var bassFx: BassBoost? = null
    private var virt: Virtualizer? = null
    private var loudFx: LoudnessEnhancer? = null
    private var fxOn = true
    private var pending: Media? = null
    private var surfaceOk = false

    // 0..100: Bass, Saaf awaaz, 3D surround, Loudness
    private val v = intArrayOf(60, 50, 60, 40)
    private val bars = mutableListOf<SeekBar>()
    private val tabs = mutableListOf<TextView>()
    private val pool = Executors.newFixedThreadPool(3)
    private val cache = LruCache<Uri, Bitmap>(80)

    private lateinit var nowText: TextView
    private lateinit var grid: GridView
    private lateinit var list: ListView
    private lateinit var sound: ScrollView
    private lateinit var overlay: FrameLayout
    private lateinit var sv: SurfaceView

    private val W = ViewGroup.LayoutParams.WRAP_CONTENT
    private val M = ViewGroup.LayoutParams.MATCH_PARENT
    private val blue = Color.parseColor("#1A8CFF")
    private val cyan = Color.parseColor("#00D4FF")
    private val perms = if (Build.VERSION.SDK_INT >= 33)
        arrayOf(Manifest.permission.READ_MEDIA_AUDIO, Manifest.permission.READ_MEDIA_VIDEO)
    else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()
    private fun fmt(ms: Long): String { val s = ms / 1000; return "%d:%02d".format(s / 60, s % 60) }
    private fun granted() = perms.all { ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar?.hide()

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
            setPadding(0, dp(30), 0, 0)
        }
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(16), 0, dp(16), dp(8)) }
        top.addView(TextView(this).apply {
            text = "Saaf Sound 3D"; textSize = 22f
            setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
        }, LinearLayout.LayoutParams(0, W, 1f))
        top.addView(Switch(this).apply {
            isChecked = true
            setOnCheckedChangeListener { _, on -> fxOn = on; applyFx() }
        })
        col.addView(top)

        val pages = FrameLayout(this)
        grid = GridView(this).apply {
            numColumns = 2; horizontalSpacing = dp(8); verticalSpacing = dp(10)
            setPadding(dp(16), 0, dp(16), 0); clipToPadding = false
            setOnItemClickListener { _, _, pos, _ -> open(videos, pos) }
        }
        list = ListView(this).apply { setOnItemClickListener { _, _, pos, _ -> open(music, pos) } }
        sound = buildSound()
        pages.addView(grid, FrameLayout.LayoutParams(M, M))
        pages.addView(list, FrameLayout.LayoutParams(M, M))
        pages.addView(sound, FrameLayout.LayoutParams(M, M))
        col.addView(pages, LinearLayout.LayoutParams(M, 0, 1f))

        nowText = TextView(this).apply {
            setTextColor(cyan); maxLines = 1; ellipsize = TextUtils.TruncateAt.END
            setPadding(dp(16), dp(6), dp(16), dp(6))
        }
        col.addView(nowText)

        val nav = LinearLayout(this).apply { setBackgroundColor(Color.parseColor("#0E1116")) }
        listOf("\uD83C\uDFAC Video", "\uD83C\uDFB5 Music", "\uD83C\uDF9A Sound").forEachIndexed { i, n ->
            val t = TextView(this).apply {
                text = n; gravity = Gravity.CENTER; setPadding(0, dp(14), 0, dp(14))
                setOnClickListener { show(i) }
            }
            tabs.add(t); nav.addView(t, LinearLayout.LayoutParams(0, W, 1f))
        }
        col.addView(nav)

        overlay = FrameLayout(this).apply { setBackgroundColor(Color.BLACK); visibility = View.GONE; isClickable = true }
        sv = SurfaceView(this)
        overlay.addView(sv, FrameLayout.LayoutParams(M, M, Gravity.CENTER))
        sv.holder.addCallback(object : SurfaceHolder.Callback {
            override fun surfaceCreated(h: SurfaceHolder) {
                surfaceOk = true; player?.setDisplay(h)
                pending?.let { pending = null; startPlay(it) }
            }
            override fun surfaceChanged(h: SurfaceHolder, f: Int, w: Int, hh: Int) {}
            override fun surfaceDestroyed(h: SurfaceHolder) { surfaceOk = false; player?.setDisplay(null) }
        })
        sv.setOnClickListener { player?.let { if (it.isPlaying) it.pause() else it.start() } }
        overlay.addView(TextView(this).apply {
            text = "\u2715"; textSize = 26f; setTextColor(Color.WHITE)
            setPadding(dp(20), dp(36), dp(20), dp(20)); setOnClickListener { closeVideo() }
        }, FrameLayout.LayoutParams(W, W, Gravity.TOP or Gravity.START))

        val rootFrame = FrameLayout(this)
        rootFrame.addView(col, FrameLayout.LayoutParams(M, M))
        rootFrame.addView(overlay, FrameLayout.LayoutParams(M, M))
        setContentView(rootFrame)

        show(0)
        initPlayer()
        if (granted()) scan() else ActivityCompat.requestPermissions(this, perms, 1)
    }

    private fun buildSound(): ScrollView {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), dp(16)) }
        val modes = LinearLayout(this)
        listOf(
            "Dynamic" to intArrayOf(60, 50, 60, 40),
            "Movie" to intArrayOf(80, 40, 90, 50),
            "Music" to intArrayOf(60, 60, 50, 30),
            "Voice" to intArrayOf(10, 90, 20, 40)
        ).forEach { (name, p) ->
            modes.addView(Button(this).apply {
                text = name; isAllCaps = false; textSize = 12f; setTextColor(Color.WHITE)
                backgroundTintList = ColorStateList.valueOf(Color.parseColor("#14181F"))
                setOnClickListener { for (i in 0..3) { v[i] = p[i]; bars[i].progress = p[i] }; applyFx() }
            }, LinearLayout.LayoutParams(0, W, 1f))
        }
        box.addView(modes)
        listOf("Bass", "Saaf awaaz", "3D surround", "Loudness").forEachIndexed { i, name ->
            box.addView(TextView(this).apply { text = name; setTextColor(Color.WHITE); setPadding(0, dp(12), 0, 0) })
            val sb = SeekBar(this).apply {
                max = 100; progress = v[i]
                progressTintList = ColorStateList.valueOf(blue)
                thumbTintList = ColorStateList.valueOf(cyan)
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { v[i] = p; applyFx() }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) {}
                })
            }
            bars.add(sb); box.addView(sb)
        }
        return ScrollView(this).apply { addView(box) }
    }

    private fun show(i: Int) {
        grid.visibility = if (i == 0) View.VISIBLE else View.GONE
        list.visibility = if (i == 1) View.VISIBLE else View.GONE
        sound.visibility = if (i == 2) View.VISIBLE else View.GONE
        tabs.forEachIndexed { j, t -> t.setTextColor(if (j == i) cyan else Color.GRAY) }
    }

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(rc, p, res)
        if (granted()) scan() else nowText.text = "Video/gaane dekhne ki permission chahiye"
    }

    // Phone ke saare video aur gaane khud dhundta hai
    private fun query(video: Boolean): List<Media> {
        val col = if (video) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val dur = if (video) MediaStore.Video.Media.DURATION else MediaStore.Audio.Media.DURATION
        val sel = if (video) null else "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND $dur > 30000"
        val order = if (video) "${MediaStore.MediaColumns.DATE_ADDED} DESC" else "${MediaStore.MediaColumns.TITLE} ASC"
        val out = mutableListOf<Media>()
        contentResolver.query(col, arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.TITLE, dur), sel, null, order)?.use { c ->
            while (c.moveToNext())
                out.add(Media(c.getString(1) ?: "Untitled", ContentUris.withAppendedId(col, c.getLong(0)), c.getLong(2)))
        }
        return out
    }

    private fun scan() {
        videos = query(true); music = query(false)
        grid.adapter = videoAdapter()
        list.adapter = object : ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, music.map { it.title }) {
            override fun getView(pos: Int, cv: View?, parent: ViewGroup): View {
                val tv = super.getView(pos, cv, parent) as TextView
                tv.setTextColor(if (queue === music && pos == qi) cyan else Color.WHITE)
                tv.maxLines = 1; tv.ellipsize = TextUtils.TruncateAt.END
                return tv
            }
        }
        nowText.text = "${videos.size} video, ${music.size} gaane mile"
    }

    private fun thumb(m: Media, iv: ImageView) {
        iv.tag = m.uri
        val c = cache.get(m.uri)
        if (c != null) { iv.setImageBitmap(c); return }
        iv.setImageDrawable(null)
        pool.execute {
            val bmp = try {
                if (Build.VERSION.SDK_INT >= 29) contentResolver.loadThumbnail(m.uri, Size(320, 180), null) else null
            } catch (e: Exception) { null }
            if (bmp != null) cache.put(m.uri, bmp)
            runOnUiThread { if (iv.tag == m.uri) iv.setImageBitmap(bmp) }
        }
    }

    private fun videoAdapter() = object : BaseAdapter() {
        val w = (resources.displayMetrics.widthPixels - dp(40)) / 2
        override fun getCount() = videos.size
        override fun getItem(p: Int) = videos[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(p: Int, cv: View?, parent: ViewGroup): View {
            val box = cv ?: build()
            val h = box.tag as Array<*>
            val m = videos[p]
            (h[1] as TextView).text = fmt(m.ms)
            (h[2] as TextView).text = m.title
            thumb(m, h[0] as ImageView)
            return box
        }
        private fun build(): View {
            val ctx = this@MainActivity
            val box = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
            val fr = FrameLayout(ctx)
            val iv = ImageView(ctx).apply { scaleType = ImageView.ScaleType.CENTER_CROP; setBackgroundColor(Color.parseColor("#1B2028")) }
            fr.addView(iv, FrameLayout.LayoutParams(w, w * 9 / 16))
            val d = TextView(ctx).apply {
                textSize = 11f; setTextColor(Color.WHITE)
                setBackgroundColor(Color.parseColor("#99000000")); setPadding(dp(5), 0, dp(5), 0)
            }
            fr.addView(d, FrameLayout.LayoutParams(W, W, Gravity.BOTTOM or Gravity.END))
            val t = TextView(ctx).apply {
                maxLines = 2; ellipsize = TextUtils.TruncateAt.END; textSize = 12f
                setTextColor(Color.WHITE); setPadding(0, dp(4), 0, 0)
            }
            box.addView(fr); box.addView(t)
            box.tag = arrayOf(iv, d, t)
            return box
        }
    }

    private fun initPlayer() {
        val p = MediaPlayer()
        p.setOnCompletionListener { next() }
        p.setOnErrorListener { _, _, _ -> next(); true }
        p.setOnVideoSizeChangedListener { _, w, h ->
            if (w > 0 && h > 0 && overlay.width > 0) {
                val s = min(overlay.width / w.toFloat(), overlay.height / h.toFloat())
                sv.layoutParams = FrameLayout.LayoutParams((w * s).toInt(), (h * s).toInt(), Gravity.CENTER)
            }
        }
        player = p
        val s = p.audioSessionId
        runCatching { eq = Equalizer(0, s).also { it.enabled = true } }
        runCatching { bassFx = BassBoost(0, s).also { it.enabled = true } }
        runCatching { virt = Virtualizer(0, s).also { it.enabled = true } }
        runCatching { loudFx = LoudnessEnhancer(s).also { it.enabled = true } }
        applyFx()
    }

    private fun open(l: List<Media>, pos: Int) {
        val m = l.getOrNull(pos) ?: return
        queue = l; qi = pos
        if (l === videos) {
            overlay.visibility = View.VISIBLE
            if (surfaceOk) startPlay(m) else pending = m
        } else startPlay(m)
    }

    private fun startPlay(m: Media) {
        val p = player ?: return
        try {
            p.reset()
            p.setAudioAttributes(
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MOVIE).build()
            )
            if (overlay.visibility == View.VISIBLE && surfaceOk) p.setDisplay(sv.holder)
            p.setDataSource(this, m.uri)
            p.prepare(); p.start()
            nowText.text = m.title
            (list.adapter as? BaseAdapter)?.notifyDataSetChanged()
        } catch (e: Exception) { next() }
    }

    private fun next() {
        if (qi + 1 in queue.indices) { qi++; startPlay(queue[qi]) }
        else if (overlay.visibility == View.VISIBLE) closeVideo()
    }

    private fun closeVideo() {
        pending = null
        runCatching { player?.reset() }
        overlay.visibility = View.GONE
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (overlay.visibility == View.VISIBLE) closeVideo() else super.onBackPressed()
    }

    private fun applyFx() {
        val on = fxOn
        runCatching { bassFx?.setStrength(if (on) (v[0] * 10).toShort() else 0.toShort()) }
        runCatching { virt?.setStrength(if (on) (v[2] * 10).toShort() else 0.toShort()) }
        runCatching { loudFx?.setTargetGain(if (on) v[3] * 8 else 0) }
        runCatching {
            val e = eq ?: return@runCatching
            val max = e.bandLevelRange[1].toInt()
            fun lvl(x: Int): Short = if (on) ((x - 50) / 50f * max).toInt().toShort() else 0.toShort()
            for (b in 0 until e.numberOfBands) {
                val hz = e.getCenterFreq(b.toShort()) / 1000
                val level: Short = when {
                    hz < 150 -> lvl(v[0])
                    hz < 1000 -> 0.toShort()
                    hz < 6000 -> lvl(v[1])
                    else -> (lvl(v[1]) / 2).toShort()
                }
                e.setBandLevel(b.toShort(), level)
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        runCatching { eq?.release(); bassFx?.release(); virt?.release(); loudFx?.release() }
        player?.release(); player = null
        pool.shutdown()
    }
}
